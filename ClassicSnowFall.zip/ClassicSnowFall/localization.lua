-- Version : English
SF_SELFCAST_DISABLED = "Classic Snowfall ALT SelfCast now disabled.";
SF_SELFCAST_ENABLED = "Classic Snowfall ALT SelfCast now enabled.";



-- Version : Russian ( by Maus )
if ( GetLocale() == "ruRU" ) then
	SF_SELFCAST_DISABLED = "Snowfall: Применение на себя по клавише ALT – отключено.";
	SF_SELFCAST_ENABLED = "Snowfall: Применение на себя по клавише ALT – включено.";
end







