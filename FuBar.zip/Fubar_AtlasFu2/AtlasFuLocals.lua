local L = AceLibrary("AceLocale-2.0"):new("AtlasFu");

L:RegisterTranslations("enUS", function() return {
	["tabletHint"] = "Click to show Atlas.",
	["labelName"] = "Atlas",
} end);

L:RegisterTranslations("ruRU", function() return {
	["tabletHint"] = "Нажмите, чтобы показать Атлас.",
	["labelName"] = "Атлас",
} end);