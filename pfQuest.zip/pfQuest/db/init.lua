pfDB = {
  ["items"] = {},
  ["spawns"] = {},
  ["quests"] = {},
  ["vendors"] = {},
  ["zones"] = {},
}
