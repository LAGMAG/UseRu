
KLHThreatMeter Release 17

Kenco@Perenolde
http://www.curse-gaming.com/en/wow/addons-3488-1-klhthreatmeter.html

KLHThreatMeter monitors and records your threat, and will list your threat in a table with other members of your party or raid group who are using the mod. Most class talents, abilities, and items that cause or modify threat are taken into account. There is a table for your personal threat contribution, broken into specific categories such as white damage, healing, mana gain, etc, and specific abilities such as Sunder Armor and Taunt. The mod records your own threat and sends updates into a shared channel. Other players in your raid who are also using the mod will pick up the messages and see you in their raid threat window. 

In WoW, type /ktm for a list of useful commands.

The following files in this folder have some random tips and documentation:

"Advanced Raid Commands.txt"	raid officers / leaders should read this
"Localisation Notes.txt"	explanation of the localisation implementation
"Development - My To Do List.txt" stuff i'm working on, or about to work on
"How You Can Help!.txt"		adding new items / abilities / bosses to the mod.
"Implementation Notes.txt"	description of how the code works for addon authors
