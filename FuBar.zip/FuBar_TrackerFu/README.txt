FuBar 2 - Tracker v2.1

Author: Schelli
Change Tracking and Sense abilities with FuBar2.

----------------------------------------

I took the liberty to convert it to ace2

----------------------------------------

previous author of Ace 1 version :

http://dev.wowace.com/wowace/branches/FuBar_Tracker/Tekkub/

FuBar - Tracker v1.0.4

Author: Corgi (corgi@writer.com)
Website: http://corgi.wowinterface.com
Release Date: 06-13-2006
Change Tracking and Sense abilities with FuBar.

TO INSTALL: Put the FuBar_Tracker folder into
	\World of Warcraft\Interface\AddOns\

