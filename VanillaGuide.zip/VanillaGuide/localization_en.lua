--by CFM
--GuideTable.lua
VG_L_TAUREN="Tauren";
VG_L_UNDEAD="Undead";
VG_L_HUMAN="Human";
VG_L_NIGHTELF="Night Elf";
VG_L_HORDE="Horde";
-- VG_L_=;
-- VG_L_=;
-- VG_L_=;
-- VG_L_=;
-- VG_L_=;
-- VG_L_=;
-- VG_L_=;
-- VG_L_=;