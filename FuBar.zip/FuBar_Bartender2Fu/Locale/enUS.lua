local L = AceLibrary("AceLocale-2.2"):new("Bartender2Fu")

L:RegisterTranslations("enUS", function() return {

	["FuBarPlugin Config"] = true,
	["Configure the FuBar Plugin"] = true,
	["ActionBar lock |cffffffcf[|r|cffff0000Off|cffffffcf]|r"] = true,
	["ActionBar lock |cffffffcf[|r|cff00ff00On|cffffffcf]|r"] = true,
	["Buttons:"] = true,
	["Locked"] = true,
	["Status:"] = true,
	["Unlocked"] = true,
	["Left-click to Lock/Unlock.\nRight-click to configure."] = true,
	

} end)