This mod is mostly for lazy people:

AUTO SAVE 	          		- character's data after receiving rare/epic item, finishing bg 
AUTO DISMOUNT 				- when casting spell or interacting with flightmaster(aq40 mounts included)
AUTO ACCEPT INVITES			- from guildmates - instant(optional)
AUTO ENTER/LEAVE BATTLEGROUNDS		- enter 2 seconds before confirm time expire
AUTO ACCEPT SUMMON	  		- accept 2 seconds before confirm time expire
AUTO ACCEPT RESURECTION			- instant accept(optional)
AUTO OPEN TAXI/BATTLE MENU		- when talking to NPC
AUTO POSITION LOOT WINDOW 		- under the cursor when looting
AUTO SPLIT 				- alt + right or shift + right will split stacked items 
AUTO COMPLETE REPEATABLE QUESTS		- like rep/bg marks(read below) 

typing /lp    - customize addon functionality
typing /dnd   - disable addon(when dnd)
typing /afk   - disable auto join bg(avoid afk join and deserter)


NEW in v1.7 
Added new feature record/replay for repeatable quests that allows you to complete them extremely fast.
To record just hold down the Shift key and complete the repeatable quest, after that talk to the NPC again and all
the previous actions will be auto replayed, remember not to release the Shift key.

New in v1.8
Added split feature
- alt + right click will split stack to half
- shift + right click will split stack (default split result is 1 to change it type: /lps value  - where value must be between 1-99)

cheers Ogrisch
