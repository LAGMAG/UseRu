# Automaton
Reduces interface tedium by doing the little things for you

##### Attack - Automatically autoattack, when you are attacked
##### Clam - Search clam shells in inventory and open them after looting
##### Dismount - Automatically dismount, cancel forms druid, shaman, priest, when you receive the appropriate error
##### Filter - Always default to showing only available spells and skill at trainers
##### Gossip - Navigates gossip and quest text for you.
##### Group - Automatically accepts group invites from anyone in your guild or friends list.
##### Invite - Options for sending players invites automatically via keywords.
##### Loner - Decline guild invites.
##### LootBOP - Ignore BOP confirm message when not in a party or raid
##### Plates - Show Target Plates (default is V button) when in combat, and hide when not in combat.
##### Purchases - Automatically restock reagents
##### Queue - Joins battlegrounds queues automatically, can also join after a delay by using /auto queue delay.
##### Ready - Auto ready when checking raid
##### Release - Release to ghost in battlegrounds.
##### Repair - Repairs all items any time you're at a vendor.
##### Rez - Automatically accepts resurrection requests you receive.
##### Sell - Sell all gray items when interacting with vendor.
##### Stand - Automatically stand when you receive the 'You must be standing' error
##### Summon - Accepts summons automatically.
##### Wuss - Supress duel invitations by declining them, like the wuss you are.
