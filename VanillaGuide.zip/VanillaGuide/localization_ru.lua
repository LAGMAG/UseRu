if( GetLocale() == "ruRU" ) then
--by CFM
--GuideTable.lua
VG_L_TAUREN="Таурен";
VG_L_UNDEAD="Нежить";
VG_L_HUMAN="Человек";
VG_L_NIGHTELF="Ночной Эльф";
VG_L_HORDE="Орда";
end