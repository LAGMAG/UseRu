Version:  1.2
Home URL: http://wwww.dd.org/~tale/wow/TalentSafe.zip

This addon pops up a confirmation dialog when you spend your talent
points.

Currently it does it for each point spent, which admittedly would be a
bit of a hassle when you're level 60 and respeccing 51 points. You
might want to turn off the addon from the player selection screen
before you do that; currently no provision is made to enable/disable
confimations from within the game.

TODO
================

In the future I would like to adapt this to be able to spend all your
talent points at once, and then confirm (and actually learn) the whole
set of changes when satisfied. This would be a much nicer interface
during respeccing, but is considerably more complicated than just
confirming a point before you spend it.

HISTORY
================
Version 1.2
        - Fixed to work with Blizzard's dynamically loaded TalentUI.

Version 1.1
        - Localization for the single word, "Learn".
        - Added README.txt

Version 1.0
	- Initial release.
